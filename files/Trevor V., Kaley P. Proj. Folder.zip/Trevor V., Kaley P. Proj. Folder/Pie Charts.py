'''
heading
'''

# Get the directory name for data files
from pylab import *
import os.path
matplotlib.rcParams['text.color'] = 'w'
directory = os.path.dirname(os.path.abspath(__file__)) 
filename = os.path.join(directory, 'AP CSP Project.txt')
datafile = open(filename, 'r')

titles=[]
label = ['Landline w/ Wireless', 'Landline w/o Wireless', 'Other', 'Wireless Only', 'None']

fracs = [[] for i in range(7)]

#this loop draws from 
for i, line in enumerate(datafile):
    households, num_households, landline_wireless, landline_only, other_1, other_2, wireless_only, none, total = line.split('\t')
    other = float(other_1) + float(other_2) 
    titles.append(str(households))
    fracs[i].append(float(landline_wireless))
    fracs[i].append(float(landline_only))
    fracs[i].append(float(other))
    fracs[i].append(float(wireless_only))
    fracs[i].append(float(none))
datafile.close()



colors = ['red', 'blue', 'purple',
'green', 'gray']

'fig, ax = plt.subplots(1,7)'

for k in range(7):
    fig, ax = plt.subplots(1,1)
    ax.pie(fracs[k], labels=label, colors=colors, autopct='%.0f%%')
    ax.set_aspect(1) # Square axes for round plot
    ax.set_title(titles[k], color='white')
    fig.show()
    fig.set_facecolor('black')
